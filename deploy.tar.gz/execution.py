import logging
import time as _time
import requests
import pandas as pd
from datetime import datetime, date, timedelta
from config import Config

logger = logging.getLogger(__name__)

class UpstoxExecutionEngine:
    def __init__(self, credentials: dict = None, mode: str = None):
        """
        Args:
            credentials: dict with keys upstox_access_token, analytics_token,
                         upstox_client_id, upstox_client_secret.
                         If None, falls back to Config (legacy single-user mode).
            mode: "TEST" or "LIVE". If None, defaults to Config.MODE.
        """
        self.api_v2  = "https://api.upstox.com/v2"
        self.api_v3  = "https://api.upstox.com/v3"
        # HFT endpoint for order placement (Place/Modify/Cancel Order V3)
        # Official Upstox docs: https://upstox.com/developer/api-documentation/v3/place-order
        # Correct URL: https://api-hft.upstox.com/v3/order/place  (V3, not V2!)
        self.api_hft = "https://api-hft.upstox.com/v3"
        self._creds = credentials  # per-user credentials dict or None
        self.mode = mode or Config.MODE

    def _get_headers(self, use_analytics=False):
        if self._creds:
            token = self._creds.get("analytics_token", "") if use_analytics else self._creds.get("upstox_access_token", "")
            if not token:  # fall through to the other token if one is empty
                token = self._creds.get("upstox_access_token", "") or self._creds.get("analytics_token", "")
        else:
            token = Config.UPSTOX_ACCESS_TOKEN
            if use_analytics and Config.ANALYTICS_TOKEN:
                token = Config.ANALYTICS_TOKEN
        return {
            'Accept': 'application/json',
            'Authorization': f'Bearer {token}',
        }


    def connect(self):
        logger.info("Initializing Upstox API Connection...")
        try:
            res = requests.get(f"{self.api_v2}/user/profile", headers=self._get_headers(), timeout=10)
            if res.status_code == 200:
                logger.info("Connected to Upstox API successfully.")
                return True
            else:
                logger.error(f"Failed to connect to Upstox API: {res.text}")
                return False
        except Exception as e:
            logger.error(f"Upstox connection error: {e}")
            return False

    def get_funds(self, force_live: bool = False) -> float:
        """Fetch real user balance (available margin) if LIVE mode is enabled or force_live is True."""
        if force_live or getattr(Config, 'USE_LIVE_CAPITAL', False):
            try:
                url = f"{self.api_v2}/user/get-funds-and-margin"
                res = requests.get(url, headers=self._get_headers(), timeout=5)
                if res.status_code == 200:
                    data = res.json()
                    if 'data' in data and 'equity' in data['data']:
                        return float(data['data']['equity'].get('available_margin', 0))
                else:
                    logger.warning(f"Upstox Funds API returned {res.status_code}: {res.text}")
            except Exception as e:
                logger.error(f"Error fetching live funds: {e}")
            return 0.0  # If live capital fails, do NOT fallback to manual capital for safety
        return getattr(Config, 'MANUAL_CAPITAL', 10000.0)

    def get_ltp(self, instrument_key: str) -> float:
        """Fetch real-time Last Traded Price (LTP) using Full Market Quotes API."""
        try:
            url = f"{self.api_v2}/market-quote/quotes?instrument_key={instrument_key}"
            # Indices can use analytics token
            use_analytics = "INDEX" in instrument_key
            response = requests.get(url, headers=self._get_headers(use_analytics), timeout=5)
            
            if response.status_code == 401 and not use_analytics:
                # Try fallback to analytics for any quote if main fails
                response = requests.get(url, headers=self._get_headers(True), timeout=5)
            response.raise_for_status()
            data = response.json()
            
            if 'data' in data and len(data['data']) > 0:
                # Upstox returns keys like "NSE_EQ:NHPC", just grab the first available value
                quote_data = list(data['data'].values())[0]
                if 'last_price' in quote_data:
                    return float(quote_data['last_price'])
                    
            logger.error(f"LTP not found in response for {instrument_key}")
        except Exception as e:
            logger.error(f"Error fetching LTP for {instrument_key}: {e}")
        return 0.0

    def get_ltp_bulk(self, instrument_keys: list) -> dict:
        """Fetch multiple LTPs in one REST sweep to avoid rate limiting UI tracking."""
        prices = {}
        try:
            if not instrument_keys:
                return prices
            keys_str = ",".join(instrument_keys)
            url = f"{self.api_v2}/market-quote/quotes?instrument_key={keys_str}"
            # Check if any index keys are present
            use_analytics = any("INDEX" in k for k in instrument_keys) if 'instrument_keys' in locals() else False
            response = requests.get(url, headers=self._get_headers(use_analytics), timeout=5)
            
            if response.status_code == 401 and not use_analytics:
                response = requests.get(url, headers=self._get_headers(True), timeout=5)
                
            response.raise_for_status()
            data = response.json()
            
            if 'data' in data:
                # Upstox returns keys like "NSE_EQ:RELIANCE" but we send "NSE_EQ|INE002A01018"
                # Build a fast reverse lookup: convert pipe-format keys to colon-format for matching
                # e.g. "NSE_EQ|INE002A01018" -> we DON'T know ticker, so match by colon key prefix
                # Upstox also accepts instrument_key in response as-is in some cases.
                # Most reliable: match by raw_key directly replacing colon with pipe.
                key_map = {}
                for k in instrument_keys:
                    # "NSE_EQ|INE002A01018" -> try "NSE_EQ:INE002A01018" as potential return key
                    colon_version = k.replace('|', ':')
                    key_map[colon_version] = k
                    key_map[k] = k  # also direct match

                for raw_key, quote_data in data['data'].items():
                    if 'last_price' in quote_data:
                        matched_key = key_map.get(raw_key)
                        if matched_key:
                            prices[matched_key] = float(quote_data['last_price'])
                        else:
                            # Fallback: match by the part after colon/pipe, and use Config.SYMBOLS_MAPPING
                            suffix = raw_key.split(':')[-1].split('|')[-1]
                            
                            # E.g. raw_key="NSE_EQ:RELIANCE" -> suffix="RELIANCE"
                            if suffix in Config.SYMBOLS_MAPPING:
                                mapped_key = Config.SYMBOLS_MAPPING[suffix]
                                if mapped_key in instrument_keys:
                                    prices[mapped_key] = float(quote_data['last_price'])
                                    continue
                            
                            for k in instrument_keys:
                                if suffix in k:
                                    prices[k] = float(quote_data['last_price'])
                                    break
        except Exception as e:
            logger.warning(f"LTP bulk fetch error: {e}")
        return prices

    def get_market_quotes(self, instrument_keys: list) -> dict:
        """Fetch full quote data (OHLC, LTP, etc.) for multiple instruments."""
        quotes = {}
        try:
            if not instrument_keys:
                return quotes
            keys_str = ",".join(instrument_keys)
            url = f"{self.api_v2}/market-quote/quotes?instrument_key={keys_str}"
            use_analytics = any("INDEX" in k for k in instrument_keys)
            response = requests.get(url, headers=self._get_headers(use_analytics), timeout=5)
            
            if response.status_code == 401 and not use_analytics:
                response = requests.get(url, headers=self._get_headers(True), timeout=5)

            response.raise_for_status()
            data = response.json()
            
            if 'data' in data:
                # Map by colon and pipe versions
                key_map = {}
                for k in instrument_keys:
                    key_map[k.replace('|', ':')] = k
                    key_map[k] = k

                for raw_key, quote_data in data['data'].items():
                    matched_key = key_map.get(raw_key)
                    if matched_key:
                        quotes[matched_key] = quote_data
                    else:
                        # Fallback for ISIN-based keys mapped to ticker name in API response
                        suffix = raw_key.split(':')[-1].split('|')[-1]
                        if suffix in Config.SYMBOLS_MAPPING:
                            mapped_key = Config.SYMBOLS_MAPPING[suffix]
                            if mapped_key in instrument_keys:
                                quotes[mapped_key] = quote_data
                                continue
                        for k in instrument_keys:
                            if suffix in k:
                                quotes[k] = quote_data
                                break
        except Exception as e:
            logger.warning(f"Market quotes fetch error: {e}")
        return quotes

    def get_ohlc(self, instrument_key: str, interval: str = "1minute") -> pd.DataFrame:
        """
        Fetch historical candles using Intraday Candle Data V3 API.
        Unit: minutes, Interval: 1
        """
        try:
            url = f"{self.api_v3}/historical-candle/intraday/{instrument_key}/minutes/1"
            
            response = requests.get(url, headers=self._get_headers(True), timeout=10) # OHLC often works with analytics token
            response.raise_for_status()
            data = response.json()
            
            if 'data' in data and 'candles' in data['data']:
                candles = data['data']['candles']
                
                # Format: [timestamp, open, high, low, close, volume, open_interest]
                df = pd.DataFrame(candles, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume', 'oi'])
                
                # Upstox V3 returns chronological newest first, reverse it to oldest first for pandas rolling features
                df = df.iloc[::-1].reset_index(drop=True)
                
                df['timestamp'] = pd.to_datetime(df['timestamp'])
                for col in ['open', 'high', 'low', 'close', 'volume']:
                    df[col] = df[col].astype(float)
                    
                if interval != "1minute":
                    resample_map = {"5minute": "5min", "15minute": "15min", "30minute": "30min", "60minute": "60min"}
                    if interval in resample_map:
                        df = df.set_index('timestamp').resample(resample_map[interval]).agg({
                            'open': 'first',
                            'high': 'max',
                            'low': 'min',
                            'close': 'last',
                            'volume': 'sum',
                            'oi': 'last'
                        }).dropna().reset_index()
                        
                return df
            else:
                logger.error(f"No candlestick data returned for {instrument_key}: {data}")
                return pd.DataFrame()
        except requests.exceptions.HTTPError as he:
            logger.error(f"HTTP Error fetching OHLC for {instrument_key}: {he.response.text}")
        except Exception as e:
            logger.error(f"Error fetching OHLC for {instrument_key}: {e}")
        
        return pd.DataFrame()

    def get_order_book(self) -> list:
        if self.mode == "TEST":
            return []
        try:
            url = f"{self.api_v2}/order/retrieve-all"
            response = requests.get(url, headers=self._get_headers(), timeout=10)
            if response.status_code == 200:
                data = response.json()
                return data.get('data', [])
            else:
                logger.error(f"Failed to fetch order book: {response.text}")
        except Exception as e:
            logger.error(f"Error fetching order book: {e}")
        return []

    def get_order_status(self, order_id: str) -> dict:
        """
        Retrieves status of a specific order.
        """
        if self.mode == "TEST":
            return {"status": "success", "order_status": "complete", "filled_quantity": 0}
        try:
            orders = self.get_order_book()
            for o in orders:
                if o.get('order_id') == order_id:
                    return {
                        "status": "success",
                        "order_status": o.get('status'),
                        "filled_quantity": int(o.get('filled_quantity', 0)),
                        "quantity": int(o.get('quantity', 0)),
                        "average_price": float(o.get('average_price', 0.0))
                    }
        except Exception as e:
            logger.error(f"Error fetching order status for {order_id}: {e}")
        return {"status": "error", "reason": "Order not found or API error"}

    def verify_order_by_details(self, instrument_token: str, transaction_type: str, qty: int, max_age_seconds: int = 60) -> dict:
        """
        Checks order book to see if a matching order was placed within the last max_age_seconds.
        """
        try:
            orders = self.get_order_book()
            import pytz
            from datetime import datetime
            now = datetime.now(pytz.timezone('Asia/Kolkata'))
            for o in orders:
                if o.get('instrument_token') == instrument_token and o.get('transaction_type') == transaction_type and int(o.get('quantity', 0)) == qty:
                    ts_str = o.get('order_timestamp')
                    if ts_str:
                        try:
                            # Upstox timestamp: '2026-06-27T15:02:40+05:30'
                            if ts_str.endswith('+05:30'):
                                ts_str = ts_str[:-6] + '+0530'
                            ts = datetime.strptime(ts_str[:19], "%Y-%m-%dT%H:%M:%S")
                            ts = pytz.timezone('Asia/Kolkata').localize(ts)
                            age = (now - ts).total_seconds()
                            if age <= max_age_seconds:
                                return {
                                    "status": "success", 
                                    "order_id": o.get('order_id'), 
                                    "order_status": o.get('status'), 
                                    "filled_quantity": int(o.get('filled_quantity', 0))
                                }
                        except Exception as e:
                            logger.error(f"Error parsing order timestamp {ts_str}: {e}")
        except Exception as e:
            logger.error(f"Error in verify_order_by_details: {e}")
        return {"status": "not_found"}

    def place_order_with_retry(self, symbol: str, side: str, qty: int, order_type: str = 'MARKET', price: float = 0.0, max_retries: int = 1) -> dict:
        """Place order with retry logic and ghost position protection (Bug Fix 1 & 2)."""
        transaction_type = "BUY" if side.upper() == "BUY" else "SELL"
        
        payload = {
            "quantity":          qty,
            "product":           "I",          # I = Intraday (MIS)
            "validity":          "DAY",
            "price":             price,
            "tag":               "intBot",
            "instrument_token":  symbol,
            "order_type":        order_type,   # MARKET / LIMIT / SL / SL-M
            "transaction_type":  transaction_type,
            "disclosed_quantity": 0,
            "trigger_price":     0,
            "is_amo":            False,
            "slice":             False,
            # market_protection: -1 = auto (per Upstox V3 docs)
            # 0 = no protection → exchange REJECTS market orders via API
            "market_protection": -1
        }

        retries = 0
        last_order_id = None  # Track any order_id we get back for verification
        
        while retries <= max_retries:
            logger.info(f"[{self.mode}] API Call: Place {side} {order_type} for {symbol}, Qty: {qty}. Attempt {retries + 1}")
            
            if self.mode == "TEST":
                logger.info(f"TEST MODE: Simulated successful {side} execution.")
                return {
                    "status": "success", "order_id": f"test_ord_{symbol}_{side}_{retries}",
                    "filled_quantity": qty, "average_price": price or 0.0
                }
            
            try:
                # Use HFT endpoint for intraday order placement (product='I')
                url = f"{self.api_hft}/order/place"
                headers = {**self._get_headers(), 'Content-Type': 'application/json'}
                logger.info(f"Placing order via HFT endpoint: {url}")
                response = requests.post(url, headers=headers, json=payload, timeout=10)
                
                response_data = response.json()
                logger.info(f"Upstox Place Order API Response: {response_data}")
                
                if response.status_code == 200 and response_data.get('status') == 'success':
                    # Extract order_ids from V3 format which returns 'order_ids' list or 'order_id'
                    order_ids = response_data['data'].get('order_ids', [])
                    order_id = order_ids[0] if order_ids else response_data['data'].get('order_id')
                    last_order_id = order_id
                    
                    # Bug Fix 2: Fetch actual filled_quantity from order status
                    _time.sleep(0.5)  # Brief wait for exchange fill
                    status_res = self.get_order_status(order_id)
                    filled_qty = qty  # Default to requested qty
                    avg_price = 0.0
                    if status_res.get('status') == 'success':
                        filled_qty = status_res.get('filled_quantity', qty)
                        avg_price = status_res.get('average_price', 0.0)
                    
                    return {
                        "status": "success", "order_id": order_id,
                        "filled_quantity": filled_qty, "average_price": avg_price
                    }
                else:
                    logger.error(f"Upstox Order Rejected: {response_data}")
                    retries += 1
                    
            except Exception as e:
                logger.error(f"API Crash/Timeout during order placement: {str(e)}")
                
                # Bug Fix 1: Ghost Position Protection
                # Wait 2 seconds, then verify actual server-side status
                logger.info("[BUG FIX 1] Waiting 2s before verifying order status on Upstox...")
                _time.sleep(2)
                
                # First try: Check by order_id if we have one
                if last_order_id:
                    status_res = self.get_order_status(last_order_id)
                    if status_res.get('status') == 'success':
                        order_status = status_res.get('order_status', '').lower()
                        if order_status in ('complete', 'traded', 'filled'):
                            logger.info(f"[BUG FIX 1] Order {last_order_id} confirmed FILLED on Upstox despite timeout.")
                            return {
                                "status": "success", "order_id": last_order_id,
                                "filled_quantity": status_res.get('filled_quantity', qty),
                                "average_price": status_res.get('average_price', 0.0)
                            }
                
                # Second try: Check order book by details
                verify_res = self.verify_order_by_details(symbol, transaction_type, qty)
                if verify_res.get('status') == 'success':
                    logger.info(f"[BUG FIX 1] Verified order exists in book: {verify_res}")
                    return {
                        "status": "success", "order_id": verify_res['order_id'],
                        "filled_quantity": verify_res.get('filled_quantity', qty),
                        "average_price": 0.0
                    }
                
                # If status check also fails → UNKNOWN status
                logger.critical(
                    f"[BUG FIX 1] ORDER STATUS UNKNOWN for {symbol} ({side}). "
                    f"Order ID: {last_order_id or 'N/A'}. Manual check required!"
                )
                return {
                    "status": "unknown",
                    "reason": "Order status could not be verified after timeout",
                    "order_id": last_order_id,
                    "symbol": symbol
                }
                
        # Final safety verification check
        logger.info("Final verification check in order book before declaring failure...")
        verify_res = self.verify_order_by_details(symbol, transaction_type, qty)
        if verify_res.get('status') == 'success':
            logger.info(f"Final verify confirmed order: {verify_res}")
            return {
                "status": "success", "order_id": verify_res['order_id'],
                "filled_quantity": verify_res.get('filled_quantity', qty),
                "average_price": 0.0
            }

        logger.error(f"Failed to place {side} order for {symbol} after {max_retries} retries.")
        return {"status": "error", "reason": "Max retries exceeded"}

    def place_stop_loss(self, symbol: str, side: str, qty: int, sl_price: float) -> dict:
        transaction_type = "SELL" if side.upper() == "BUY" else "BUY"
        logger.info(f"[{self.mode}] Placing Stop Loss ({transaction_type}) at {sl_price} for {symbol}")
        
        rounded_sl = round(sl_price * 20) / 20.0
        
        payload = {
            "quantity": qty,
            "product": "I",
            "validity": "DAY",
            "price": 0,
            "tag": "intBotSL",
            "instrument_token": symbol,
            "order_type": "SL-M",
            "transaction_type": transaction_type,
            "disclosed_quantity": 0,
            "trigger_price": rounded_sl,
            "is_amo": False,
            "slice": False
        }

        if self.mode == "TEST":
            logger.info(f"TEST MODE: Simulated SL placement at {rounded_sl}.")
            return {"status": "success", "order_id": f"test_sl_{symbol}_{side}"}
            
        try:
            # Use HFT endpoint for intraday SL order placement
            url = f"{self.api_hft}/order/place"
            headers = {**self._get_headers(), 'Content-Type': 'application/json'}
            logger.info(f"Placing SL order via HFT endpoint: {url}")
            response = requests.post(url, headers=headers, json=payload, timeout=10)
            response_data = response.json()
            
            if response.status_code == 200 and response_data.get('status') == 'success':
                order_ids = response_data['data'].get('order_ids', [])
                order_id = order_ids[0] if order_ids else response_data['data'].get('order_id')
                return {"status": "success", "order_id": order_id}
            else:
                logger.error(f"Upstox SL Order Rejected: {response_data}")
                return {"status": "error"}
                
        except Exception as e:
            logger.error(f"API Crash during SL placement: {str(e)}")
            return {"status": "error", "reason": str(e)}

    def modify_order(self, order_id: str, new_price: float, new_trigger: float, qty: int, order_type: str = "SL-M") -> dict:
        if self.mode == "TEST":
            logger.info(f"TEST MODE: Modifying order {order_id}.")
            return {"status": "success"}

        payload = {
            "order_id": order_id,
            "quantity": qty,
            "validity": "DAY",
            "price": new_price,
            "order_type": order_type,
            "disclosed_quantity": 0,
            "trigger_price": new_trigger
        }
        try:
            # Use HFT endpoint for order modification
            url = f"{self.api_hft}/order/modify"
            headers = {**self._get_headers(), 'Content-Type': 'application/json'}
            response = requests.put(url, headers=headers, json=payload, timeout=10)
            response_data = response.json()
            
            if response.status_code == 200 and response_data.get('status') == 'success':
                return {"status": "success"}
            else:
                logger.error(f"Failed to modify order {order_id}: {response_data}")
                return {"status": "error"}
        except Exception as e:
            logger.error(f"API Crash modifying {order_id}: {e}")
            return {"status": "error"}

    def cancel_order(self, order_id: str) -> dict:
        if self.mode == "TEST":
            logger.info(f"TEST MODE: Canceling order {order_id}.")
            return {"status": "success"}

        try:
            # Use HFT endpoint for order cancellation
            url = f"{self.api_hft}/order/cancel?order_id={order_id}"
            response = requests.delete(url, headers=self._get_headers(), timeout=10)
            response_data = response.json()
            if response.status_code == 200 and response_data.get('status') == 'success':
                return {"status": "success"}
            else:
                logger.error(f"Failed to cancel {order_id}: {response_data}")
                return {"status": "error"}
        except Exception as e:
            logger.error(f"API Crash canceling {order_id}: {e}")
            return {"status": "error"}

    def exit_all_positions(self) -> dict:
        if self.mode == "TEST":
            logger.info("TEST MODE: Simulated Exit All Positions.")
            return {"status": "success"}
            
        try:
            url = f"{self.api_v2}/order/positions/exit"
            headers = {**self._get_headers(), 'Content-Type': 'application/json'}
            # Payload is empty or can pass tag='intBot'
            response = requests.post(url, headers=headers, json={}, timeout=10)
            response_data = response.json()
            if response.status_code in [200, 207] and response_data.get('status') in ['success', 'partial_success']:
                logger.info(f"Successfully sent exit-all command: {response_data}")
                return {"status": "success", "data": response_data}
            else:
                logger.error(f"Exit all positions failed: {response_data}")
                return {"status": "error"}
        except Exception as e:
            logger.error(f"API Crash extending all positions: {e}")
            return {"status": "error"}

    # ── v2 Pipeline Methods ────────────────────────────────────────────────────

    def get_historical_candles_daily(self, instrument_key: str, days: int = 30) -> pd.DataFrame:
        """Fetch daily historical candles for Layer 1 pre-filter."""
        try:
            to_date = date.today().isoformat()
            from_date = (date.today() - timedelta(days=days)).isoformat()
            url = f"{self.api_v3}/historical-candle/{instrument_key}/days/1/{to_date}/{from_date}"
            response = requests.get(url, headers=self._get_headers(True), timeout=15)
            response.raise_for_status()
            data = response.json()

            if 'data' in data and 'candles' in data['data']:
                candles = data['data']['candles']
                df = pd.DataFrame(candles, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume', 'oi'])
                df = df.iloc[::-1].reset_index(drop=True)  # Oldest first
                df['timestamp'] = pd.to_datetime(df['timestamp'])
                for col in ['open', 'high', 'low', 'close', 'volume']:
                    df[col] = df[col].astype(float)
                return df
            else:
                logger.error(f"No daily candle data for {instrument_key}: {data}")
                return pd.DataFrame()
        except Exception as e:
            logger.error(f"Error fetching daily candles for {instrument_key}: {e}")
            return pd.DataFrame()

    def get_trade_book(self) -> list:
        """Fetch today's trade book from Upstox for reconciliation (Section 10)."""
        if self.mode == "TEST":
            return []
        try:
            url = f"{self.api_v2}/order/trades/get-trades-for-day"
            response = requests.get(url, headers=self._get_headers(), timeout=10)
            if response.status_code == 200:
                data = response.json()
                return data.get('data', [])
            else:
                logger.error(f"Failed to fetch trade book: {response.text}")
        except Exception as e:
            logger.error(f"Error fetching trade book: {e}")
        return []
